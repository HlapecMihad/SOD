<?php

require_once __DIR__ . '/../Database.php';
$log_file = __DIR__ . '/log.txt';

function log_data($data)
{
    global $log_file;
    $log_entry = "[" . date('Y-m-d H:i:s') . "] " . $data . "\n";
    file_put_contents($log_file, $log_entry, FILE_APPEND);
}

class Uporabnik {
    private $db;

    public function __construct()
    {
        try {
            $dbConnect = new Database();
            $this->db = $dbConnect->connect();
        } catch (Exception $e) {
            // Handle connection failure gracefully
            throw new Exception("Failed to initialize database connection: " . $e->getMessage());
        }
    }

    public function vrniUporabnike()
    {
        log_data("Fetching all users");
        try {
            // Select only the fields needed for the frontend
            $query = "SELECT id_uporabnika AS idUporabnik, ime, priimek, mail FROM uporabnik";
            $stmt = $this->db->prepare($query);
            $stmt->execute();
            $uporabniki = $stmt->fetchAll(PDO::FETCH_ASSOC);

            // Return the users in a structured response
            return [
                "status" => "success",
                "data" => $uporabniki,
            ];
        } catch (PDOException $e) {
            // Log the error and return a structured error response
            log_data("Error fetching users: " . $e->getMessage());
            return [
                "status" => "error",
                "message" => "Error fetching users: " . $e->getMessage(),
            ];
        }
    }
}

?>
