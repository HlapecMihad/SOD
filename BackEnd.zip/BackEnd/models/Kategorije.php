<?php
class Kategorije {
    public $idKategorije;
    public $naziv;

    public function __construct($idKategorije = null, $naziv = null) {
        $this->idKategorije = $idKategorije;
        $this->naziv = $naziv;
    }
}
?>
