<?php
class Oglas {
    public $idOglas;
    public $text;
    public $datumObjave;
    public $Kategorije_idKategorije;
    public $Uporabnik_idUporabnik;

    public function __construct($idOglas = null, $text = null, $datumObjave = null, $Kategorije_idKategorije = null, $Uporabnik_idUporabnik = null) {
        $this->idOglas = $idOglas;
        $this->text = $text;
        $this->datumObjave = $datumObjave;
        $this->Kategorije_idKategorije = $Kategorije_idKategorije;
        $this->Uporabnik_idUporabnik = $Uporabnik_idUporabnik;
    }
}
?>
