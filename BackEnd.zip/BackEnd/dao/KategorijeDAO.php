<?php
class KategorijeDAO {
    private $conn;

    public function __construct($db) {
        $this->conn = $db;
    }

    public function create($kategorije) {
        $query = "INSERT INTO Kategorije (naziv) VALUES (:naziv)";
        $stmt = $this->conn->prepare($query);
        $stmt->bindParam(":naziv", $kategorije->naziv);
        return $stmt->execute();
    }

    public function readAll() {
        $query = "SELECT * FROM Kategorije";
        $stmt = $this->conn->prepare($query);
        $stmt->execute();
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }

    public function readById($id) {
        $query = "SELECT * FROM Kategorije WHERE idKategorije = :id";
        $stmt = $this->conn->prepare($query);
        $stmt->bindParam(":id", $id);
        $stmt->execute();
        return $stmt->fetch(PDO::FETCH_ASSOC);
    }

    public function delete($id) {
        $query = "DELETE FROM Kategorije WHERE idKategorije = :id";
        $stmt = $this->conn->prepare($query);
        $stmt->bindParam(":id", $id);
        return $stmt->execute();
    }
}
?>
