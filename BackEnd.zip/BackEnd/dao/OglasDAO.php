<?php
class OglasDAO {
    private $conn;

    public function __construct($db) {
        $this->conn = $db;
    }

    public function create($oglas) {
        $query = "INSERT INTO Oglas (text, datumObjave, Kategorije_idKategorije, Uporabnik_idUporabnik) 
                  VALUES (:text, :datumObjave, :Kategorije_idKategorije, :Uporabnik_idUporabnik)";
        $stmt = $this->conn->prepare($query);
        
        $stmt->bindParam(":text", $oglas->text);
        $stmt->bindParam(":datumObjave", $oglas->datumObjave);
        $stmt->bindParam(":Kategorije_idKategorije", $oglas->Kategorije_idKategorije);
        $stmt->bindParam(":Uporabnik_idUporabnik", $oglas->Uporabnik_idUporabnik);

        return $stmt->execute();
    }

    public function readAll() {
        $query = "SELECT * FROM Oglas";
        $stmt = $this->conn->prepare($query);
        $stmt->execute();
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }

    public function readById($id) {
        $query = "SELECT * FROM Oglas WHERE idOglas = :id";
        $stmt = $this->conn->prepare($query);
        $stmt->bindParam(":id", $id);
        $stmt->execute();
        return $stmt->fetch(PDO::FETCH_ASSOC);
    }

    public function update($oglas) {
        $query = "UPDATE Oglas SET text = :text, datumObjave = :datumObjave, 
                  Kategorije_idKategorije = :Kategorije_idKategorije, 
                  Uporabnik_idUporabnik = :Uporabnik_idUporabnik WHERE idOglas = :id";
        $stmt = $this->conn->prepare($query);

        $stmt->bindParam(":text", $oglas->text);
        $stmt->bindParam(":datumObjave", $oglas->datumObjave);
        $stmt->bindParam(":Kategorije_idKategorije", $oglas->Kategorije_idKategorije);
        $stmt->bindParam(":Uporabnik_idUporabnik", $oglas->Uporabnik_idUporabnik);
        $stmt->bindParam(":id", $oglas->idOglas);

        return $stmt->execute();
    }

    public function delete($id) {
        $query = "DELETE FROM Oglas WHERE idOglas = :id";
        $stmt = $this->conn->prepare($query);
        $stmt->bindParam(":id", $id);
        return $stmt->execute();
    }
}
?>
