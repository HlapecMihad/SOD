<?php

class UporabnikDAO {
    private $conn;

    public function __construct($db) {
        if (!$db) {
            throw new Exception("Database connection is null in UporabnikDAO.");
        }
        $this->conn = $db;
    }

    // Create a new user
    public function create($uporabnik) {
        try {
            $query = "INSERT INTO uporabnik (ime, priimek, mail, password) VALUES (:ime, :priimek, :mail, :password)";
            $stmt = $this->conn->prepare($query);

            // Bind parameters
            $stmt->bindParam(":ime", $uporabnik->ime);
            $stmt->bindParam(":priimek", $uporabnik->priimek);
            $stmt->bindParam(":mail", $uporabnik->mail);
            $stmt->bindParam(":password", $uporabnik->password);

            return $stmt->execute(); // Return true if the query is successful
        } catch (PDOException $e) {
            throw new Exception("Error creating user: " . $e->getMessage());
        }
    }

    // Retrieve all users
    public function vrniVse() {
        try {
            $query = "SELECT idUporabnik, ime, priimek, mail FROM uporabnik"; // Exclude password for security
            $stmt = $this->conn->prepare($query);
            $stmt->execute();
            return $stmt->fetchAll(PDO::FETCH_ASSOC); // Return all users as an associative array
        } catch (PDOException $e) {
            throw new Exception("Error fetching all users: " . $e->getMessage());
        }
    }

    // Retrieve a specific user by ID
    public function vrniDolocenega($id) {
        try {
            $query = "SELECT idUporabnik, ime, priimek, mail FROM uporabnik WHERE idUporabnik = :id";
            $stmt = $this->conn->prepare($query);

            // Bind parameter
            $stmt->bindParam(":id", $id, PDO::PARAM_INT);
            $stmt->execute();

            return $stmt->fetch(PDO::FETCH_ASSOC); // Return the user as an associative array
        } catch (PDOException $e) {
            throw new Exception("Error fetching user by ID: " . $e->getMessage());
        }
    }

    // Update an existing user
    public function update($uporabnik) {
        try {
            $query = "UPDATE uporabnik SET ime = :ime, priimek = :priimek, mail = :mail WHERE idUporabnik = :id";
            $stmt = $this->conn->prepare($query);

            // Bind parameters
            $stmt->bindParam(":ime", $uporabnik->ime);
            $stmt->bindParam(":priimek", $uporabnik->priimek);
            $stmt->bindParam(":mail", $uporabnik->mail);
            $stmt->bindParam(":id", $uporabnik->idUporabnik, PDO::PARAM_INT);

            return $stmt->execute(); // Return true if the query is successful
        } catch (PDOException $e) {
            throw new Exception("Error updating user: " . $e->getMessage());
        }
    }

    // Delete a user by ID
    public function delete($id) {
        try {
            $query = "DELETE FROM uporabnik WHERE idUporabnik = :id";
            $stmt = $this->conn->prepare($query);

            // Bind parameter
            $stmt->bindParam(":id", $id, PDO::PARAM_INT);

            return $stmt->execute(); // Return true if the query is successful
        } catch (PDOException $e) {
            throw new Exception("Error deleting user: " . $e->getMessage());
        }
    }
}
?>
