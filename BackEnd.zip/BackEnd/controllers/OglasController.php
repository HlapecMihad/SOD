<?php
include_once 'Database.php';
include_once 'models/Oglas.php';
include_once 'dao/OglasDAO.php';

class OglasController {
    private $dao;

    public function __construct() {
        $database = new Database();
        $db = $database->getConnection();
        $this->dao = new OglasDAO($db);
    }

    public function createOglas($data) {
        if (empty($data['text']) || empty($data['datumObjave']) || empty($data['Kategorije_idKategorije']) || empty($data['Uporabnik_idUporabnik'])) {
            return ["status" => 400, "message" => "All fields are required"];
        }

        $oglas = new Oglas(null, $data['text'], $data['datumObjave'], $data['Kategorije_idKategorije'], $data['Uporabnik_idUporabnik']);

        if ($this->dao->create($oglas)) {
            return ["status" => 201, "message" => "Advertisement created successfully"];
        } else {
            return ["status" => 500, "message" => "Failed to create advertisement"];
        }
    }

    public function getAllOglasi() {
        $oglasi = $this->dao->readAll();
        return ["status" => 200, "data" => $oglasi];
    }

    public function getOglasById($id) {
        $oglas = $this->dao->readById($id);
        if ($oglas) {
            return ["status" => 200, "data" => $oglas];
        } else {
            return ["status" => 404, "message" => "Advertisement not found"];
        }
    }

    public function updateOglas($data) {
        if (empty($data['id']) || empty($data['text']) || empty($data['datumObjave']) || empty($data['Kategorije_idKategorije']) || empty($data['Uporabnik_idUporabnik'])) {
            return ["status" => 400, "message" => "All fields are required"];
        }

        $oglas = new Oglas($data['id'], $data['text'], $data['datumObjave'], $data['Kategorije_idKategorije'], $data['Uporabnik_idUporabnik']);
        if ($this->dao->update($oglas)) {
            return ["status" => 200, "message" => "Advertisement updated successfully"];
        } else {
            return ["status" => 500, "message" => "Failed to update advertisement"];
        }
    }

    public function deleteOglas($id) {
        if ($this->dao->delete($id)) {
            return ["status" => 200, "message" => "Advertisement deleted successfully"];
        } else {
            return ["status" => 500, "message" => "Failed to delete advertisement"];
        }
    }
}
?>
