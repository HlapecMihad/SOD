<?php

include_once __DIR__ .  '/../dao/UporabnikDAO.php';
include_once __DIR__ .  '/../models/Uporabnik.php';
include_once __DIR__ .  '/../Database.php';

class UporabnikController {
   public function vrniUporabnike()
   {
       $uporabnikModel = new Uporabnik();
       $uporabniki = $uporabnikModel->vrniUporabnike();

       log_data(print_r($uporabnikModel->vrniUporabnike()));
       echo json_encode($uporabniki);
   }
}
?>
