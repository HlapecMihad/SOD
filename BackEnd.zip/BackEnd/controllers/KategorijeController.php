<?php
class KategorijeController {
    private $dao;

    public function __construct() {
        $database = new Database();
        $db = $database->getConnection();
        $this->dao = new KategorijeDAO($db);
    }

    public function createKategorije($data) {
        if (empty($data['naziv'])) {
            return ["status" => 400, "message" => "Category name is required"];
        }

        $kategorije = new Kategorije(null, $data['naziv']);
        if ($this->dao->create($kategorije)) {
            return ["status" => 201, "message" => "Category created successfully"];
        } else {
            return ["status" => 500, "message" => "Failed to create category"];
        }
    }

    public function getAllKategorije() {
        $categories = $this->dao->readAll();
        return ["status" => 200, "data" => $categories];
    }

    public function deleteKategorije($id) {
        if ($this->dao->delete($id)) {
            return ["status" => 200, "message" => "Category deleted successfully"];
        } else {
            return ["status" => 500, "message" => "Failed to delete category"];
        }
    }
}
?>
