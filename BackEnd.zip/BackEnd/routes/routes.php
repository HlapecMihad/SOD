<?php
// Include controllers using absolute paths
require_once __DIR__ . '/../Database.php';
include_once __DIR__ . '/../controllers/UporabnikController.php';
include_once __DIR__ . '/../controllers/OglasController.php';
include_once __DIR__ . '/../controllers/KategorijeController.php';

header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Headers: *");
header("Access-Control-Allow-Methods: *");

$request_method = $_SERVER['REQUEST_METHOD'];
$endpoint = isset($_GET['action']) ? $_GET['action'] : '';

switch ($endpoint) {
    case 'login':
        if ($request_method === 'POST') {
            $input = json_decode(file_get_contents('php://input'), true);
            $loginController = new LoginController();
            $loginController->login($input);
        } else {
            echo json_encode(['message' => 'Invalid request method']);
        }
        break;

    case 'register':
        if ($request_method === 'POST') {
            $input = json_decode(file_get_contents('php://input'), true);
            $registrationController = new RegistrationController();
            $registrationController->register($input);
        } else {
            echo json_encode(['message' => 'Invalid request method']);
        }
        break;
        
        case 'vrniUporabnike':
         if ($request_method === 'GET') {
             $uporabnikController = new uporabnikController();
             $uporabnikController->vrniUporabnike();
         } else {
             echo json_encode(['message' => 'Invalid request method']);
         }
         break;

    case 'getTask':
        if ($request_method === 'GET') {
            $email = $_GET['email'];
            $taskController = new TaskController();
            $taskController->getTask($email);
        } else {
            echo json_encode(['message' => 'Invalid request method']);
        }
        break;
    case 'addTask':
        if ($request_method === 'POST') {
            $input = json_decode(file_get_contents('php://input'), true);
            $taskController = new TaskController();
            $taskController->addTask($input);
        } else {
            echo json_encode(['message' => 'Invalid request method']);
        }
        break;
    case 'deleteTask':
        if ($request_method === 'DELETE') {
            $input = json_decode(file_get_contents('php://input'), true);
            log_data($input['id']);
            if (isset($input['id'])) {
                $taskController = new TaskController();
                $taskController->deleteTask($input['id']);
                echo json_encode(['status' => 'success', 'message' => 'Task deleted successfully']);
            } else {
                echo json_encode(['status' => 'error', 'message' => 'Task ID is missing']);
            }
        } else {
            echo json_encode(['message' => 'Invalid request method']);
        }
        break;
    case 'checkTask':
        if ($request_method === 'PUT') {
            $input = json_decode(file_get_contents('php://input'), true);
            log_data($input);
            if (isset($input)) {
                $taskController = new TaskController();
                $taskController->checkTask($input);
                echo json_encode(['status' => 'success', 'message' => 'Opravilo uspešno posodobljeno']);
            } else {
                echo json_encode(['status' => 'error', 'message' => 'Task ID is missing']);
            }
        } else {
            echo json_encode(['message' => 'Invalid request method']);
        }
        break;
    case 'getCategories':
        if ($request_method === 'GET') {
            $email = $_GET['email'];
            $categoryController = new CategoryController();
            $categoryController->getCategories($email);
        } else {
            echo json_encode(['message' => 'Invalid request method']);
        }
        break;
    case 'addCategory':
        if ($request_method === 'POST') {
            $input = json_decode(file_get_contents('php://input'), true);
            $categoryController = new CategoryController();
            $categoryController->addCategory($input);
        } else {
            echo json_encode(['message' => 'Invalid request method']);
        }
        break;

    case 'editTask':
        if ($request_method === 'PUT') {
            $input = json_decode(file_get_contents('php://input'), true);
            $taskController = new TaskController();
            $taskController->editTask($input);
        } else {
            echo json_encode(['message' => 'Invalid request method']);
        }
        break;
    default:
        echo json_encode(['message' => 'Invalid endpoint']);
        break;
}
?>
